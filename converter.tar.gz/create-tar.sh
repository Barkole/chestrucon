#/bin/bash
tar -czvf converter.tar.gz --exclude=converter.tar.gz *
