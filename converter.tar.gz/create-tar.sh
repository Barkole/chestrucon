#/bin/bash
rm converter.tar.gz
tar -czvf converter.tar.gz --exclude=*~ *
